﻿internal class Program
{
    static void Main()
    {
        string[] nombre = new string[5];
        int[] edad = new int[5];

        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine("Ingrese un nombre:");
            nombre[i] = Console.ReadLine();
            
            Console.WriteLine("Ingrese la edad:");
            edad[i] = int.Parse(Console.ReadLine());
        }

        for (int i = 0; i < 5; i++)
        {
            if (edad[i] > 17)
            {
                Console.WriteLine("Nombre de un mayor de edad: " + nombre[i]);
            }
        }
    }
}