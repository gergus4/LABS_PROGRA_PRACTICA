﻿internal class Program
{
    static void Main(string[] args)
    {
        string op;
        Console.WriteLine("BIENVENIDO A LA AUTOMATIZACIÓN AUTO-HOME");
        Console.WriteLine("POR FAVOR SELECCIONE LA OPCIÓN CORRESPONDIENTE AL SISTEMA QUE DESEA ELEGIR");
        Console.WriteLine("1: VENTILACIÓN");
        Console.WriteLine("2: CALEFACCIÓN");
        Console.WriteLine("3: SALIR DE AUTO-HOME");
        Console.WriteLine("*Recordatorio: sin importar que opción eliga, siempre se le mostrará que habitación tiene la luz prendida");
        op = Console.ReadLine();
        switch (op)
        {
            case 1:




                // METER LA RANDOMIZACION DE LA LUZ
                break;

            case 2:



                // METER LA RANDOMIZACION DE LA LUZ
                break;

            case 3:
                Console.WriteLine("SE HA CERRADO AUTO-HOME");

                // METER LA RANDOMIZACION DE LA LUZ
                break;
        }
    }
}